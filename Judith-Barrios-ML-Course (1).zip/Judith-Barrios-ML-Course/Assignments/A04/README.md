# Assignment 04 — IIoT Protocol Lab: Reflective Journal

**Course:** ITAI 3377  
**Date:** February 2026  
**Group:** Brandy Griffin, Michael Garcia, Judith Barrios  
**My Role:** Research, OPC UA support, written documentation

---

## Overview

This assignment was the written reflection component for Lab 04, covering the group's experience building a three-protocol IIoT sensor simulation from scratch. It documents what each team member contributed, what each protocol taught us, how we solved real errors, and where this kind of work could go in the future.

## My Contributions to the Project

I handled three areas: pre-development research, OPC UA support during testing, and the written components of the project.

Before any code was written, I compiled notes on MQTT, CoAP, and OPC UA — their architectures, intended use cases, and the trade-offs between them. That research helped the team make better decisions during implementation. When the OPC UA script threw a `TypeError` on node operations, I cross-referenced the asyncua documentation to confirm the correct async/await usage, which helped Brandy isolate and fix the issue. On the documentation side, I drafted the learning outcomes analysis, reviewed all written materials for accuracy, and wrote the future applications section.

## What Each Protocol Taught Me

**MQTT** — The publish-subscribe pattern makes much more sense after you've actually run it. One thing I did not expect was the threading complication in the visualization: MQTT callbacks run on a background thread, and Tkinter requires all GUI calls to come from the main thread. The fix (routing data through a thread-safe queue) was a practical Python concurrency lesson that applies well beyond this project.

**CoAP** — The REST-like request-response structure helped us get oriented quickly, but CoAP runs over UDP rather than TCP, which means it trades some reliability for lower overhead. The `2.04 Changed OK` responses were satisfying confirmation that the server was receiving data. The port conflict issue (port 5683 still held by a previous process) was exactly the kind of real-world friction that makes labs valuable — it's not a problem you'd encounter in a tutorial.

**OPC UA** — This is not just a protocol; it is a full data-modeling framework. Namespaces, typed variables, and access permissions exist because in industrial environments the *context* of data matters as much as its value. The security warning about plaintext password transfer during local testing was a useful reminder that OPC UA includes enterprise-grade authentication and encryption features — which is why industrial automation uses it when reliability matters most.

## Errors We Solved

| Error | Cause | Fix |
|-------|-------|-----|
| `RuntimeError: Calling Tcl from different apartment` | matplotlib called from MQTT background thread | Routed data through a thread-safe queue; only main thread updates the chart |
| Port 5683 already in use | Previous CoAP server process still bound the port | Used `netstat -ano | findstr :5683` to find PID, then `taskkill /PID <id> /F` |
| `TypeError` on OPC UA node operations | Missing `await` on asyncua coroutine calls | Applied `await` consistently to all node operations per asyncua documentation |

## Files

| File | Description |
|------|-------------|
| `A04_Judith_Barrios_ITAI_3377.docx` | Full group reflective journal |
