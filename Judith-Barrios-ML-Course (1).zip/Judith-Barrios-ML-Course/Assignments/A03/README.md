# Assignment 03 — Edge-Computing Video Analytics for Smart City Traffic Monitoring

**Course:** ITAI 3377  
**Date:** January 28, 2026  
**Type:** Case Study Analysis

---

## Problem Being Solved

Urban planners in Liverpool, UK faced a growing challenge: pedestrian and vehicle traffic was increasing with city expansion, but collecting reliable movement data using traditional methods was expensive, disruptive, and raised significant privacy concerns. Existing CCTV infrastructure was underutilized, and sending raw video to a central server would have created privacy and bandwidth problems.

The Liverpool Smart Pedestrians project asked: can edge computing turn existing cameras into a useful planning tool without ever storing or transmitting actual video footage?

## Approach and Technology Used

The system was built on an **NVIDIA Jetson TX2** — a compact device with enough GPU power for real-time inference while consuming minimal energy. Object detection used **YOLO V3**, chosen for its balance of speed and accuracy on embedded hardware. The **SORT tracking algorithm** followed detected objects across frames to count and map movement.

All video processing happened locally at the camera — meaning raw footage never left the device. Only summarized outputs (counts, movement paths) were transmitted, which satisfied privacy regulations without sacrificing useful data.

This approach directly applies the edge-computing model from course Module 2: processing close to the data source reduces latency, lowers network load, and keeps sensitive data local.

## Results

- **Average detection accuracy:** ~69% (validated against the Oxford Town Center annotated dataset)
- **Processing speed:** ~20 frames per second (real-time)
- **System stability:** CPU, GPU, memory, and network usage remained stable across extended deployments
- **Real-world deployments:** Indoor building evacuation monitoring (confirmed building cleared during fire alarm) and outdoor Liverpool city center pedestrian/vehicle flow monitoring

## Challenges and Limitations

- Accuracy dropped in dense crowds due to occlusion (objects blocking each other)
- The SORT tracking algorithm ran on CPU rather than GPU, creating a performance bottleneck
- The project was completed in 2019 — newer detection models and edge hardware would likely improve results significantly

## My Evaluation

The project succeeded in demonstrating that edge-based video analytics can deliver actionable urban planning data without requiring new infrastructure or compromising privacy. The ~69% accuracy is honest — it is not perfect, but it captures overall traffic trends reliably enough for planning decisions. The fact that the system ran stably over long periods is arguably more important than peak accuracy for this kind of deployment.

Broader research supports the direction: distributing processing to edge nodes rather than relying on centralized cloud systems enables faster responses and more flexible city infrastructure (Kummara, 2024).

## Files

| File | Description |
|------|-------------|
| `A03_Judith_Barrios_ITAI_3377.docx` | Full written case study analysis |
