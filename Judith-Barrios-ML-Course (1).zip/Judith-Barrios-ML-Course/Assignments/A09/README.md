# Assignment 09 — Autonomous Agents in Industry 4.0: Case Study Analysis

**Course:** ITAI 3377  
**Type:** Case Study Analysis + Personal Reflection  
**Source:** Hjulstrom, L. (2022). *Reinforcement Learning for Autonomous Guided Vehicles*. KTH Royal Institute of Technology.

---

## Problem Being Solved

Traditional Automated Guided Vehicles (AGVs) in warehouses follow fixed paths using physical floor markers and depend on a central controller — making them slow to adapt when conditions change. Hjulstrom's 2022 KTH thesis asked whether reinforcement learning could make these vehicles autonomous: able to navigate, manage their own battery, and complete tasks through trial and error instead of being told exactly what to do at each step.

## How the System Was Built

The simulation ran three agents in a 10×10 grid warehouse, each assigned to carry objects between locations while monitoring battery level and visiting charging stations before running out of power. The system was built in Python using TensorFlow and TF-Agents, using a **Double Deep Q-Network (DDQN)** algorithm.

Each agent received four inputs at every step: its own grid position, the target location, current battery level, and the state of the four surrounding squares. From this, it chose to move up, down, left, or right.

**Reward structure:**
- +100 for reaching a target
- –70 for colliding with a wall or another agent
- –100 for running out of battery
- –1 per step taken (encourages efficiency)

Training ran for 200,000 episodes. Task difficulty increased every 30,000 episodes, forcing the agents to learn battery management alongside navigation.

## Results

After training, all three agents completed all 300 assigned tasks across the full test run with zero crashes and zero battery failures. They averaged only 2.59 extra steps per task beyond the shortest possible route — accounting for recharging detours and collision avoidance.

Removing physical floor markers is one of the most practical benefits: those markers are expensive to maintain, require vehicles to go offline for cleaning, and create downtime. The learning-based approach eliminates this entirely. Because each agent operates independently with no central controller, the system keeps working even if one agent fails.

## Limitations

- Tested only in a 2D simulation with one fixed layout — real-world performance is unknown
- Agents had no communication with each other or with charging stations (no queue awareness)
- Battery behavior was unrealistically simple: constant drain, instant recharge
- ~47% of U.S. jobs could be at risk from automation (mentioned briefly in the paper — deserves more serious discussion)

## My Reflection

This case study changed how I think about reinforcement learning. The reward function design is the real work — how you assign points and penalties is what shapes agent behavior, and getting it wrong means the agent learns something useless or harmful. That lesson extends well beyond robotics: any system learning from feedback is only as good as the feedback design.

The automation and job displacement point stuck with me. The paper spends two sentences on it before moving on, which felt disproportionate to the scale of the issue. Systems like this one are designed to replace real people doing real work right now. The technical results deserve to be taken seriously — and so does the human cost.

## Files

| File | Description |
|------|-------------|
| `A09_Judith_Barrios_ITAI3377.pdf` | Full case study analysis and personal reflection |
