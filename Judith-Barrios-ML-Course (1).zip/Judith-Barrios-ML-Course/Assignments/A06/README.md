# Assignment 06 — Group Presentation

**Course:** ITAI 3377  
**Group:** Group 5

---

## Overview

This assignment was a group video presentation summarizing the team's work and findings from the course. The presentation covered key topics from the IIoT and edge AI labs completed by the group.

## Files

| File | Description |
|------|-------------|
| `A06_Group05_Judith_Barrios_ITAI3377.mov` | Group video presentation (file too large for GitHub — kept locally) |
