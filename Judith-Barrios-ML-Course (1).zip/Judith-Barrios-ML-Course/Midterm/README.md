# Midterm — Cybersecurity Plan for an AI-Integrated IIoT Healthcare System

**Course:** ITAI 3377  
**Date:** Week 4  
**Group:** Group 5  
**Submitted By:** Judith Barrios

---

## Problem Being Solved

Hospitals are among the most targeted industries for cyberattacks, and the stakes are uniquely high: a breach doesn't just expose data — it can directly affect patient safety. This project designed a comprehensive cybersecurity plan for a hypothetical **Hospital Patient Monitoring Network (HPMN)**: a connected system where patient devices (monitors, infusion pumps, wearables) feed into an AI system that helps doctors make faster decisions.

The challenge was treating this as a real threat model — not just listing security best practices, but identifying exactly where the system was vulnerable and designing layered defenses that hold up when individual controls fail.

## System Components

- Medical IoT devices (ECG monitors, smart pumps, wearable patches, glucose monitors, portable imaging)
- Edge gateways in each hospital ward
- Hospital Wi-Fi and wired network
- Electronic Health Records (EHR) platform
- Four AI models: sepsis prediction, X-ray analysis, medication dosing, patient deterioration detection
- Clinical staff devices (laptops, tablets, phones)

## Vulnerability Assessment (15 Vulnerabilities Identified)

Vulnerabilities were mapped across seven layers: device, network, data, application, AI model, human, and physical.

**Critical vulnerabilities included:**
- Default passwords still active on medical devices
- Unpatched firmware with known CVEs enabling remote code execution
- Patient data transmitted over MQTT without encryption
- Patient records not encrypted at rest (major HIPAA violation)
- SQL injection exposure in the EHR web portal
- AI training data pipeline susceptible to poisoning attacks

**Additional high-severity issues:**
- No network segmentation (lateral movement possible after one compromise)
- Rogue Wi-Fi access point attacks
- Adversarial inputs capable of fooling diagnostic AI (e.g., modified X-ray causing wrong diagnosis)
- Staff vulnerability to phishing attacks

## Defense Strategy (9 Categories)

The defense plan used a **defense-in-depth** approach: no single control is relied upon; if one layer fails, others catch what gets through.

| Category | Key Controls |
|----------|-------------|
| Secure by Design | Remove default credentials; enable secure boot; use HSMs for key storage |
| Authentication & Access | MFA required; RBAC; X.509 device certificates; OAuth 2.0 for APIs |
| Encryption | TLS 1.3 on all connections; AES-256 for data at rest |
| Network Security | VLAN segmentation by device type; IDS/IPS; rogue AP detection |
| AI Model Protection | Input validation and anomaly detection; differential privacy in training; model access logging |
| Incident Response | Defined playbooks; air-gap capability for critical systems during active attacks |
| Compliance | HIPAA, HITECH, and IEC 62443 alignment |
| Staff Training | Phishing simulation; security awareness program |
| Physical Security | Device lockdown; USB port controls; access logging in patient areas |

## What I Learned

Building a threat model from scratch — going layer by layer through a system and asking "how would an attacker get in here?" — changed how I think about system design. Security can't be an afterthought. The most dangerous vulnerabilities on the list (default passwords, unencrypted MQTT traffic) are not exotic attacks. They're basic failures that happen when security isn't built into the process from the beginning.

The AI-specific vulnerabilities were the most interesting to research. Adversarial inputs and training data poisoning are problems that don't exist in traditional software — they're unique to ML systems — and the defenses require a different way of thinking about what it means for a system to be "compromised."

## Files

| File | Description |
|------|-------------|
| `MT_JudithBarrios_Group5_ITAI_3377.docx` | Full cybersecurity plan with vulnerability table, defense strategy, and system diagram |
