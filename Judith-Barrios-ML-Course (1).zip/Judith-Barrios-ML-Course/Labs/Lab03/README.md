# Lab 03 — CNN Model Deployment on a Simulated Edge Device

**Course:** ITAI 3377  
**Date:** February 7, 2026  
**Tool:** Google Colab

---

## What This Lab Was About

This lab extended the work from Lab 02 by using a more powerful Convolutional Neural Network (CNN) architecture instead of a simple dense network. The goal was to train the CNN on the MNIST dataset, convert it to TensorFlow Lite format, and validate the converted model using the TFLite interpreter — simulating how a production AI model would be prepared and deployed on an edge device.

## Model Architecture

| Layer | Details |
|-------|---------|
| Conv2D | 32 filters, 3×3 kernel, ReLU activation |
| MaxPooling2D | 2×2 pool size |
| Flatten | Converts 2D feature maps to 1D |
| Dense | 128 neurons, ReLU activation |
| Output | 10 neurons, Softmax activation |

**Total Parameters:** 693,962 trainable  
**Model Size (Keras):** ~2.65 MB  
**Model Size (TFLite):** ~2.65 MB (maintained after conversion)

## Results

| Metric | Value |
|--------|-------|
| Test Accuracy | **98.63%** |
| Test Loss | 0.0446 |
| Training Epochs | 5 |
| Sample Validation (5 images) | 5/5 correct (100%) |

## Deployment Steps

1. Trained the CNN on MNIST training data (60,000 samples)
2. Evaluated on 10,000 test samples — achieved 98.63% accuracy
3. Converted using `TFLiteConverter.from_keras_model()`
4. Saved as `model.tflite`
5. Validated using the TFLite Interpreter — confirmed conversion preserved accuracy

## What I Learned

The CNN architecture significantly outperformed the simple dense model from Lab 02. The convolutional layers learn spatial patterns in the image (edges, curves, shapes) before the dense layers classify them — which is why CNNs are the standard for image tasks.

What stood out most was how smooth the TFLite conversion was. A model trained in a full TensorFlow environment converted cleanly to a format ready for edge hardware, with no loss in accuracy on the validation samples. That end-to-end pipeline — train, convert, deploy, test — is now something I understand from practice, not just from reading about it.

## Challenges

- Correctly reshaping input images for the CNN (adding a channel dimension for grayscale)
- Understanding what MaxPooling does and why it reduces spatial dimensions without losing important features
- Verifying that TFLite output matched the original model's predictions

## Files

| File | Description |
|------|-------------|
| `L03_Judith_Barrios_NoteBook_ITAI3377.ipynb` | Full lab notebook |
| `report.docx` | Written documentation of the deployment process |
| `reflective_doc.docx` | Personal reflection |
