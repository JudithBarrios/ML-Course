# Lab 07 — IIoT Network Analysis: Age of Information & Reliability Trade-offs

**Course:** ITAI 3377  
**Tool:** Google Colab / Python

---

## What This Lab Was About

This lab analyzed Age of Information (AoI) and Packet Loss Probability (PLP) trade-offs in Industrial Internet of Things (IIoT) networks using a simulated dataset of 10,000 records. The theoretical framework came from Farag, Ali, and Stefanovic (2023).

AoI measures how *stale* the data at a receiver actually is at any given moment — which is different from latency or throughput. A network can look healthy by traditional metrics and still be feeding a controller outdated information. This lab explored what drives AoI in IIoT settings and whether machine learning could predict it.

## Dataset

- **Total records:** 10,000
- **Dropped (infinite AoI — packets never arrived):** 1,397
- **Used for ML:** 8,603 finite-AoI records
- **Key variables:** transmission probability, capture threshold, number of nodes, channel quality, traffic type (AoI-oriented vs. deadline-oriented), AoI, PLP

## Key Findings from Exploratory Analysis

- Sending more frequently does **not** simply lower AoI. At high transmission rates, competing signals collide and successful deliveries drop — raising AoI despite more transmissions. This non-obvious relationship is what makes AoI worth studying separately from delay.
- **Channel quality** had the strongest correlation with AoI — better signal conditions mean more messages get decoded successfully.
- Worst AoI values almost always appeared when both channel quality was poor *and* node count was high simultaneously.

## Machine Learning Results

### Random Forest (AoI Prediction)
| Metric | Value |
|--------|-------|
| R² | –0.37 |
| RMSE | 1,736 time slots |

The negative R² means the model performed worse than simply predicting the mean AoI every time — an honest result worth reporting. The likely cause: extreme variance in AoI values combined with the 1,397 dropped infinite rows. A log transformation before training would probably help significantly.

**Feature Importances (most to least):**
1. Capture threshold — 0.448
2. Number of nodes — 0.231
3. Channel quality — 0.171
4. Transmission probability — 0.095
5. Traffic type — 0.055

### Deep Learning (Multi-Output)
| Target | R² |
|--------|----|
| AoI | –0.20 |
| PLP | **0.91** |

The deep learning model excelled at predicting PLP (R² = 0.91) because PLP is bounded between 0 and 1 with much less extreme variance than AoI. The high PLP accuracy was the standout result of the lab.

## Practical Strategies Proposed

1. **Adaptive transmission rate** — Have monitoring devices pull back their sending frequency when a deadline-critical alert is queued, so the channel is less congested for the message that matters most.
2. **Receiver hardware upgrade** — Improving the capture threshold (interference tolerance) would reduce both AoI and PLP simultaneously without changing device behavior at all.

## What I Learned

Reporting a negative R² honestly was important. The feature importance results were more informative than the accuracy score — they confirmed the theoretical model (Farag et al., 2023) and gave actionable guidance about what actually drives network performance. This lab changed how I think about evaluating ML models: a bad accuracy number can still be a useful result if you understand *why* it failed and what the model did learn.

## Files

| File | Description |
|------|-------------|
| `L07_Notebook_Judith_Barrios_ITAI3377.ipynb` | Full lab notebook |
| `L07_Report_Judith_Barrios_ITAI3377.pdf` | Written summary report |
