# Lab 06 — IIoT Time-Series Temperature Forecasting

**Course:** ITAI 3377  
**Date:** March 25, 2026  
**Collaborator:** Brandy Griffin  
**Tool:** Google Colab

---

## What This Lab Was About

This lab applied time-series forecasting to a real IIoT temperature dataset collected from IoT sensors. The dataset contained 97,606 readings from indoor and outdoor sensors taken between July and December 2018. The goal was to clean and prepare the data, engineer meaningful features, train a forecasting model, evaluate its performance, and explore how synthetic data augmentation can improve results.

## Dataset

- **Source:** IOT-temp.csv (Kaggle IoT Temperature Forecasting Dataset)
- **Records:** 97,606 temperature readings
- **Columns:** ID, room, datetime, temperature (°C), indoor/outdoor location
- **Temperature range:** 21°C – 51°C (mean: 35°C)
- **Class distribution:** ~79% outdoor readings, ~21% indoor

## Steps Completed

1. **Data Preparation** — Cleaned column names, converted datetime strings to proper datetime format, sorted chronologically, confirmed no missing values
2. **Exploratory Analysis** — Visualized temperature over time; compared average temperature by location (outdoor readings consistently higher than indoor)
3. **Feature Engineering** — Created `hour`, `day_of_week`, `lag_1` (previous value), and `rolling_mean_3` (3-period moving average)
4. **Train/Test Split** — 80/20 time-based split (78,083 train / 19,521 test) preserving chronological order
5. **Model Training** — Linear Regression using engineered features
6. **Evaluation** — MAE and MSE on test set
7. **Synthetic Data Augmentation** — Added Gaussian noise (σ=0.5) to create a synthetic copy of the dataset; retrained on combined data
8. **Cross-Validation** — Demonstrated 3-fold time-series cross-validation using `TimeSeriesSplit`

## Results

| Model | MAE | MSE |
|-------|-----|-----|
| Baseline Linear Regression | 1.52 | 7.89 |
| Augmented (+ synthetic data) | **1.14** | **4.69** |

Synthetic data augmentation reduced MAE by ~25% and MSE by ~41%, showing that exposing the model to more varied patterns meaningfully improved its ability to generalize.

## What I Learned

Time-series forecasting requires respecting the order of data — you can never use future information to predict the past, which means random splits are wrong and time-based splits are essential. Feature engineering was the most impactful step: the lag and rolling average features gave the model information about recent trends that it couldn't infer from time alone. The improvement from synthetic augmentation surprised me — it was a simple technique but had a real effect, which made me curious about how far it could go with more sophisticated generation methods.

## Challenges

- Understanding why `lag_1` and `rolling_mean_3` required dropping the first few rows after creation
- Recognizing that the outdoor/indoor imbalance (~79% outdoor) could bias the model and should be considered in future versions
- Keeping track of whether to use the original or augmented test set during evaluation

## Files

| File | Description |
|------|-------------|
| `L06_notebook.pdf` | Full Colab notebook with code and outputs |
