# Lab 04 — IIoT Protocol Simulation: MQTT, CoAP, and OPC UA

**Course:** ITAI 3377  
**Date:** February 14–20, 2026  
**Group:** Brandie Griffin, Michael Garcia, Judith Barrios  
**My Role:** Research, OPC UA support, written documentation

---

## What This Lab Was About

This lab built a functioning IIoT sensor network simulation from the ground up, implementing three real industrial communication protocols — MQTT, CoAP, and OPC UA — in a single local Python environment. Each protocol was simulated end-to-end: a sensor script generated random temperature and humidity data, a server or broker received it, and a visualization script displayed the live data stream.

The goal was not just to understand the protocols in theory but to feel the difference between them through actual implementation and debugging.

## Protocols Implemented

### MQTT (Message Queuing Telemetry Transport)
- Sensor script published temperature and humidity to a `sensor/data` topic
- Mosquitto broker ran as a Windows service, routing messages to the subscriber
- Visualization script displayed live data using matplotlib
- **Challenge encountered:** A threading conflict caused a `RuntimeError: Calling Tcl from different apartment` — the MQTT callback ran on a background thread while Tkinter's GUI ran on the main thread. Fixed by routing data through a thread-safe queue so only the main thread updated the chart.

### CoAP (Constrained Application Protocol)
- `coap_server.py` received POST requests from the sensor client
- `coap_sensor_simulation.py` sent sensor payloads every second; confirmed with `2.04 Changed OK` responses
- **Challenge encountered:** Port 5683 was already in use after a session restart. Resolved using `netstat -ano | findstr :5683` to find the blocking process, then `taskkill /PID <id> /F` to clear it.

### OPC UA
- `opcua_sensor_simulation.py` created a structured node tree (namespace → object → Temperature and Humidity variables) and updated values in a loop
- Server ran at `opc.tcp://localhost:4840`
- **Challenge encountered:** A `TypeError` on node operations caused by missing `await` keywords in the asyncua async calls. Fixed by applying `await` consistently to all coroutine node operations.

## Key Takeaways

Each protocol serves a different purpose and feels different to work with:

- **MQTT** is fast, lightweight, and forgiving — the right choice when many small sensors need to broadcast data continuously with minimal overhead.
- **CoAP** is RESTful and runs over UDP — less overhead than HTTP but requires more attention to the network layer. Good for constrained devices.
- **OPC UA** is a full data-modeling framework, not just a protocol. It structures data with types, namespaces, and access permissions — which is why industrial automation systems use it when reliability and data context matter more than simplicity.

The bugs were some of the best learning moments. Every one of them forced a deeper understanding of the system rather than just getting something to run.

## What I Contributed

I researched all three protocols before development began, compiling notes on architecture and use cases. I assisted with OPC UA testing and cross-referenced asyncua documentation when the async compatibility error appeared. I also led the written components: the learning outcomes analysis, documentation review, and future applications section.

## Files

| File | Description |
|------|-------------|
| `LO4SCREENSHOTS.pdf` | Step-by-step screenshot evidence for all three protocol simulations |
| `A04_reflective_journal.docx` | Group reflective journal |
